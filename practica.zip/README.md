# ANTLR4_JSBach

Command line compilation:
```
antlr4 jsbach.g4
antlr4 -Dlanguage=Python3 -no-listener -visitor jsbach.g4
grun jsbach root -gui
```

Execute program:
```
python3 jsbach.py input
```

